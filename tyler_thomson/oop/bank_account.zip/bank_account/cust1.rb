require_relative 'account'
class Checking < BankAccount

end

class Savings < BankAccount

end

puts cust1 = Checking.new
